# DanChoiSmpAnticheat v1.3.0

Sửa báo nhầm Hitbox, KillAura, AutoCart, Fly, Timer.
Thêm ClickTP và Fight.

Chỉnh độ nhạy trong `checks.yml`. Buffer cao = ít báo nhầm hơn.

## Build trên GitHub (điện thoại)

Repo phải có file `DanChoiSmpAnticheat_v1.2.0.zip` (source này) và workflow giải nén nó rồi `mvn package`.
Upload đè đúng tên file đó rồi đợi Actions xanh, tải artifact.
