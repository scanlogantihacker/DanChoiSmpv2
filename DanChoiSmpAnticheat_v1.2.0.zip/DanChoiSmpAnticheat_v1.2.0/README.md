# DanChoiSmpAnticheat v1.2.0

## Thay đổi so với 1.1.0

### Config tách file
- `config.yml` – key, grim-compat, TPS, tin nhắn
- `checks.yml` – độ chính xác, buffer, ngưỡng từng check (chỉnh nhạy/khó flag tại đây)
- `punishments.yml` – VL threshold, lệnh phạt, reason
- `webhook.yml` – Discord webhook

### Key folder
Khi chưa có key hợp lệ, plugin tự tạo:
```
plugins/DanChoiSmpAnticheat/key/key.txt
```
Ghi key vào dòng cuối file đó → restart server → anticheat bật.

### Check mới
- **ElytraFly** – bay elytra tốc độ cao không dùng firework / glide không có elytra
- **AutoTotem** – equip totem offhand quá nhanh sau khi pop / damage nặng
- **AutoTrap** – đặt nhiều block bao quanh player khác trong thời gian ngắn

### Discord Webhook
Bật trong `webhook.yml`:
```yaml
enabled: true
url: "https://discord.com/api/webhooks/..."
send-on-punish: true
```

### Build
Cần Maven + Paper API + PacketEvents (provided).
```bash
mvn clean package
```
Copy `target/DanChoiSmpAnticheat.jar` vào plugins/.

### Lệnh
- `/ac reload` – tải lại toàn bộ config
- `/ac key <key>` – kích hoạt key
- `/ac alerts` – bật/tắt cảnh báo
- `/ac vl <player>` – xem VL
