package vn.danchoismp.anticheat;

import com.github.retrooper.packetevents.PacketEvents;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class DanChoiSmpAnticheat extends JavaPlugin implements CommandExecutor {

    private ConfigManager configs;
    private ViolationManager violations;
    private WebhookSender webhook;
    private PacketCheck packetCheck;
    private BasicPacketCheck basicPacketCheck;
    private MaceCheck maceCheck;
    private boolean licensed;
    private boolean started;

    public boolean isLicensed() {
        return licensed;
    }

    public ConfigManager configs() {
        return configs;
    }

    @Override
    public void onEnable() {
        configs = new ConfigManager(this);
        configs.loadAll();

        // Ưu tiên key trong config, nếu trống thì đọc từ key/key.txt
        String key = getConfig().getString("license-key", "");
        if (key == null || key.isBlank()) {
            key = LicenseManager.ensureKeyFolder(getDataFolder(), getLogger());
        } else {
            // vẫn tạo folder để user biết
            LicenseManager.ensureKeyFolder(getDataFolder(), getLogger());
        }

        licensed = LicenseManager.valid(key);
        if (licensed && (getConfig().getString("license-key", "").isBlank())) {
            // lưu key đọc từ file vào config để lần sau khỏi đọc lại
            getConfig().set("license-key", key);
            saveConfig();
            getLogger().info("Đã tải key từ key/key.txt và kích hoạt anticheat.");
        }

        getCommand("ac").setExecutor(this);

        if (!licensed) {
            getLogger().warning("Chưa có key hợp lệ! Anticheat CHƯA hoạt động.");
            getLogger().warning("Ghi key vào plugins/DanChoiSmpAnticheat/key/key.txt rồi restart,");
            getLogger().warning("hoặc điền 'license-key' trong config.yml rồi /ac reload, hoặc /ac key <key>");
            return;
        }
        startChecks();
    }

    private void startChecks() {
        if (started) return;
        started = true;

        webhook = new WebhookSender(this);
        violations = new ViolationManager(this, webhook);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(violations, this);
        pm.registerEvents(new CombatCheck(this, violations), this);
        pm.registerEvents(new VelocityCheck(this, violations), this);
        pm.registerEvents(new CartCheck(this, violations), this);
        pm.registerEvents(new CrystalCheck(this, violations), this);
        pm.registerEvents(new ChatCheck(this, violations), this);
        pm.registerEvents(new MovementCheck(this, violations), this);
        pm.registerEvents(new PlaceCheck(this, violations), this);

        // Check mới v1.2
        pm.registerEvents(new ElytraCheck(this, violations), this);
        pm.registerEvents(new AutoTotemCheck(this, violations), this);
        pm.registerEvents(new AutoTrapCheck(this, violations), this);
        pm.registerEvents(new FightCheck(this, violations), this);

        packetCheck = new PacketCheck(this, violations);
        PacketEvents.getAPI().getEventManager().registerListener(packetCheck);
        pm.registerEvents(packetCheck, this);

        basicPacketCheck = new BasicPacketCheck(this, violations);
        PacketEvents.getAPI().getEventManager().registerListener(basicPacketCheck);
        pm.registerEvents(basicPacketCheck, this);

        maceCheck = new MaceCheck(this, violations);
        PacketEvents.getAPI().getEventManager().registerListener(maceCheck);
        pm.registerEvents(maceCheck, this);

        getLogger().info("DanChoiSmpAnticheat v1.3 đã bật."
                + (yieldToGrim() ? " Phát hiện GrimAC: tự nhường các check trùng." : "")
                + " Checks: Combat, Fight, ClickTP, Fly, Cart, Crystal, Chat, Movement, Place, Elytra, AutoTotem, AutoTrap, Packet, Timer, Mace.");
    }

    @Override
    public void onDisable() {
        if (webhook != null) webhook.shutdown();
        if (!started) return;
        try {
            PacketEvents.getAPI().getEventManager().unregisterListener(packetCheck);
            PacketEvents.getAPI().getEventManager().unregisterListener(basicPacketCheck);
            PacketEvents.getAPI().getEventManager().unregisterListener(maceCheck);
        } catch (Exception ignored) {}
    }

    public boolean yieldToGrim() {
        return getConfig().getBoolean("grim-compat.yield-overlapping-checks", true)
                && getServer().getPluginManager().isPluginEnabled("GrimAC");
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage("§e/ac reload §7| §e/ac alerts §7| §e/ac vl <người chơi> §7| §e/ac key <key>");
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "reload":
                configs.reload();
                String k = getConfig().getString("license-key", "");
                if (k == null || k.isBlank()) {
                    k = LicenseManager.ensureKeyFolder(getDataFolder(), getLogger());
                    if (LicenseManager.valid(k)) {
                        getConfig().set("license-key", k);
                        saveConfig();
                    }
                }
                licensed = LicenseManager.valid(getConfig().getString("license-key", ""));
                if (licensed) startChecks();
                s.sendMessage(licensed ? "§aĐã tải lại config (checks, punishments, webhook)."
                        : "§cĐã tải lại config nhưng key không hợp lệ - anticheat đang tắt.");
                break;
            case "key":
                if (a.length < 2) {
                    s.sendMessage("§cDùng: /ac key <key>");
                    break;
                }
                if (!LicenseManager.valid(a[1])) {
                    s.sendMessage("§cKey không hợp lệ.");
                    break;
                }
                getConfig().set("license-key", a[1].trim());
                saveConfig();
                licensed = true;
                startChecks();
                s.sendMessage("§aKey hợp lệ - anticheat đã được kích hoạt.");
                break;
            case "alerts":
                if (violations == null) {
                    s.sendMessage("§cChưa kích hoạt key.");
                    break;
                }
                if (!(s instanceof Player)) {
                    s.sendMessage("Chỉ dùng trong game.");
                    break;
                }
                boolean on = violations.toggleAlerts(((Player) s).getUniqueId());
                s.sendMessage(on ? "§aĐã bật cảnh báo." : "§cĐã tắt cảnh báo.");
                break;
            case "vl":
                if (a.length < 2) {
                    s.sendMessage("§cDùng: /ac vl <người chơi>");
                    break;
                }
                if (violations == null) {
                    s.sendMessage("§cChưa kích hoạt key.");
                    break;
                }
                Player t = getServer().getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage("§cKhông tìm thấy người chơi.");
                    break;
                }
                Map<String, Double> m = violations.getVl(t.getUniqueId());
                if (m.isEmpty()) s.sendMessage("§7" + t.getName() + " chưa có vi phạm.");
                else m.forEach((k2, v) -> s.sendMessage("§7" + k2 + ": §e" + String.format("%.1f", v)));
                break;
            default:
                s.sendMessage("§cLệnh không hợp lệ.");
        }
        return true;
    }
}
