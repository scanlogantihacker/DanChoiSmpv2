package vn.danchoismp.anticheat;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.util.BoundingBox;

/** Auto Crystal: đập crystal ngay khi vừa spawn (đoán ID), quá nhanh, quá xa, không nhìn, xuyên tường. */
public class CrystalCheck implements Listener {

    private static class State {
        final Deque<Long> breaks = new ArrayDeque<>();
        double fastBuf, aimBuf;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, Long> spawned = new HashMap<>();
    private final Map<UUID, State> states = new HashMap<>();

    public CrystalCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
        // dọn bản ghi crystal cũ
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();
            spawned.values().removeIf(t -> now - t > 10_000);
        }, 200L, 200L);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpawn(EntitySpawnEvent e) {
        if (e.getEntity() instanceof EnderCrystal) {
            spawned.put(e.getEntity().getUniqueId(), System.currentTimeMillis());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player) || !(e.getEntity() instanceof EnderCrystal)) return;
        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("crystal.enabled", true)) return;
        Player p = (Player) e.getDamager();
        if (Util.skip(plugin, p)) return;

        State s = states.computeIfAbsent(p.getUniqueId(), k -> new State());
        long now = System.currentTimeMillis();
        double lag = Util.lagTolerance(p);
        boolean cancel = false;

        // 1) Đập crystal ngay khi vừa xuất hiện (người thật luôn cần >= ping)
        Long born = spawned.remove(e.getEntity().getUniqueId());
        if (born != null) {
            double minAge = Math.max(c.getDouble("crystal.min-break-age-ms", 55),
                    Math.min(Math.max(p.getPing(), 0), 300) * 0.6);
            long age = now - born;
            if (age < minAge) {
                s.fastBuf++;
                if (s.fastBuf >= c.getDouble("crystal.buffer", 3)) {
                    vm.flag(p, "AutoCrystal", "đập crystal sau " + age + "ms", 1.5);
                    cancel = true;
                }
            } else {
                s.fastBuf = Math.max(0, s.fastBuf - 0.5);
            }
        }

        // 2) Tốc độ đập
        s.breaks.addLast(now);
        while (!s.breaks.isEmpty() && now - s.breaks.peekFirst() > 1000) s.breaks.pollFirst();
        if (s.breaks.size() > c.getInt("crystal.max-breaks-per-second", 14)) {
            vm.flag(p, "AutoCrystal", s.breaks.size() + " crystal/s", 1.0);
            cancel = true;
        }

        // 3) Reach / nhìn / xuyên tường
        Location eye = p.getEyeLocation();
        BoundingBox box = e.getEntity().getBoundingBox();
        double dist = Util.distanceToBox(eye, box);
        if (dist > c.getDouble("crystal.max-reach", 3.0) + 0.3 + lag) {
            vm.flag(p, "AutoCrystal", String.format("reach %.2f", dist), 1.5);
            cancel = true;
        } else if (!box.contains(eye.toVector())) {
            BoundingBox ex = box.clone().expand(0.15 + lag * 0.5);
            if (ex.rayTrace(eye.toVector(), eye.getDirection(), dist + 2) == null) {
                s.aimBuf++;
                if (s.aimBuf >= 2) {
                    vm.flag(p, "AutoCrystal", "không nhìn vào crystal", 1.0);
                    cancel = true;
                }
            } else {
                s.aimBuf = Math.max(0, s.aimBuf - 0.5);
            }
        }
        if (Util.wallBetween(eye, box)) {
            vm.flag(p, "AutoCrystal", "đập xuyên tường", 2.0);
            cancel = true;
        }

        if (cancel) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
