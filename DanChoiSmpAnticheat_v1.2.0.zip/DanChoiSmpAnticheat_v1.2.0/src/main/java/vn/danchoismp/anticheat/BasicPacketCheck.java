package vn.danchoismp.anticheat;

import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
import com.github.retrooper.packetevents.protocol.player.User;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

/**
 * Check bằng packet kiểu Grim:
 *  - Timer: client gửi packet di chuyển nhanh hơn 20/giây (game speed hack / blink-burst)
 *  - BadPackets: pitch ngoài [-90, 90], toạ độ NaN/vô cực/quá lớn, tự đánh chính mình
 * Nhường cho GrimAC khi có (grim-compat.yield-overlapping-checks).
 */
public class BasicPacketCheck extends PacketListenerAbstract implements Listener {

    private static class State {
        volatile long lastNs;
        volatile long balanceNs;   // > 0: gửi nhanh hơn nhịp 50ms
        volatile long graceUntilMs;
    }

    private static final long TICK_NS = 50_000_000L;

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final ConcurrentHashMap<UUID, State> states = new ConcurrentHashMap<>();

    public BasicPacketCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        super(PacketListenerPriority.LOW);
        this.plugin = plugin;
        this.vm = vm;
    }

    private void grace(Player p, long ms) {
        State s = states.computeIfAbsent(p.getUniqueId(), k -> new State());
        s.balanceNs = 0;
        s.lastNs = 0;
        s.graceUntilMs = System.currentTimeMillis() + ms;
    }

    @EventHandler public void onTp(PlayerTeleportEvent e) { grace(e.getPlayer(), 1000); }
    @EventHandler public void onJoin(PlayerJoinEvent e) { grace(e.getPlayer(), 3000); }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) { grace(e.getPlayer(), 2000); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { grace(e.getPlayer(), 2000); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { states.remove(e.getPlayer().getUniqueId()); }

    @Override
    public void onPacketReceive(PacketReceiveEvent event) {
        PacketTypeCommon type = event.getPacketType();
        boolean flying = WrapperPlayClientPlayerFlying.isFlying(type);
        boolean interact = type == PacketType.Play.Client.INTERACT_ENTITY;
        if (!flying && !interact) return;

        FileConfiguration c = plugin.configs().checks();
        if (plugin.yieldToGrim()) return;

        User user = event.getUser();
        UUID id = user.getUUID();
        if (id == null) return;
        Player p = Bukkit.getPlayer(id);
        if (p == null || Util.skip(plugin, p)) return;

        if (interact) {
            if (!c.getBoolean("badpackets.enabled", true)) return;
            WrapperPlayClientInteractEntity w = new WrapperPlayClientInteractEntity(event);
            if (w.getEntityId() == p.getEntityId()) {
                vm.flag(p, "BadPackets", "tương tác với chính mình", 3.0);
                event.setCancelled(true);
            }
            return;
        }

        WrapperPlayClientPlayerFlying w = new WrapperPlayClientPlayerFlying(event);

        // ---------- BadPackets ----------
        if (c.getBoolean("badpackets.enabled", true)) {
            if (w.hasRotationChanged()) {
                float pitch = w.getLocation().getPitch();
                if (Float.isNaN(pitch) || Float.isInfinite(pitch) || Math.abs(pitch) > 90.0f) {
                    vm.flag(p, "BadPackets", "pitch không hợp lệ " + pitch, 3.0);
                    event.setCancelled(true);
                    return;
                }
            }
            if (w.hasPositionChanged()) {
                double x = w.getLocation().getX(), y = w.getLocation().getY(), z = w.getLocation().getZ();
                if (Double.isNaN(x) || Double.isNaN(y) || Double.isNaN(z)
                        || Double.isInfinite(x) || Double.isInfinite(y) || Double.isInfinite(z)
                        || Math.abs(x) > 3.0E7 || Math.abs(z) > 3.0E7 || Math.abs(y) > 1.0E5) {
                    vm.flag(p, "BadPackets", "toạ độ không hợp lệ", 5.0);
                    event.setCancelled(true);
                    return;
                }
            }
        }

        // ---------- Timer ----------
        if (!c.getBoolean("timer.enabled", true)) return;
        State s = states.computeIfAbsent(id, k -> new State());
        long nowNs = System.nanoTime();
        long last = s.lastNs;
        s.lastNs = nowNs;
        if (last == 0 || System.currentTimeMillis() < s.graceUntilMs) return;

        long creditNs = c.getLong("timer.max-lag-credit-ms", 500) * 1_000_000L;
        long maxNs = c.getLong("timer.max-balance-ms", 120) * 1_000_000L;

        long bal = s.balanceNs + TICK_NS - (nowNs - last);
        if (bal < -creditNs) bal = -creditNs;   // lag thì được "tín dụng" để bù gói dồn
        if (bal > maxNs) {
            vm.flag(p, "Timer", String.format("nhanh hơn nhịp %.0fms", bal / 1_000_000.0), 1.0);
            bal = 0;
        }
        s.balanceNs = bal;
    }
}
