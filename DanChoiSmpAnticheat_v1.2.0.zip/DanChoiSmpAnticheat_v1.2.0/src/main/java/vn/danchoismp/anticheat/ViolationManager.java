package vn.danchoismp.anticheat;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class ViolationManager implements Listener {

    private final DanChoiSmpAnticheat plugin;
    private final Map<UUID, Map<String, Double>> vls = new ConcurrentHashMap<>();
    private final Set<UUID> alertsOff = ConcurrentHashMap.newKeySet();
    private final WebhookSender webhook;

    public ViolationManager(DanChoiSmpAnticheat plugin, WebhookSender webhook) {
        this.plugin = plugin;
        this.webhook = webhook;
        long period = 20L * Math.max(1, plugin.getConfig().getInt("vl-decay-seconds", 30));
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::decay, period, period);
    }

    private void decay() {
        double amt = plugin.getConfig().getDouble("vl-decay-amount", 1.0);
        for (Map<String, Double> m : vls.values()) {
            m.replaceAll((k, v) -> Math.max(0.0, v - amt));
        }
    }

    /** An toàn khi gọi từ thread bất kỳ. Trả về VL hiện tại. */
    public double flag(Player p, String check, String info, double add) {
        String key = check.toLowerCase();
        double vl = vls.computeIfAbsent(p.getUniqueId(), k -> new ConcurrentHashMap<>())
                .merge(key, add, Double::sum);
        Runnable r = () -> handle(p, check, info, vl);
        if (Bukkit.isPrimaryThread()) r.run();
        else Bukkit.getScheduler().runTask(plugin, r);
        return vl;
    }

    private void handle(Player p, String check, String info, double vl) {
        String reason = plugin.configs().punishments().getString(
                "reasons." + check.toLowerCase(),
                plugin.configs().punishments().getString("reasons.default", "Cheat detected (%check%)")
                        .replace("%check%", check));

        String msg = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.alert",
                        "&c[AC] &f%player% &7nghi dùng &c%check% &7(%info%) &8VL: &e%vl%")
                        .replace("%player%", p.getName())
                        .replace("%check%", check)
                        .replace("%info%", info == null ? "" : info)
                        .replace("%vl%", String.format("%.1f", vl))
                        .replace("%reason%", reason));
        plugin.getLogger().info(ChatColor.stripColor(msg));
        for (Player s : Bukkit.getOnlinePlayers()) {
            if (s.hasPermission("anticheat.alerts") && !alertsOff.contains(s.getUniqueId())) {
                s.sendMessage(msg);
            }
        }

        // Gửi webhook khi flag (nếu bật)
        if (webhook != null) {
            webhook.send(p.getName(), check, info, vl, reason, false);
        }

        String key = check.toLowerCase();
        int threshold = plugin.configs().punishments().getInt("thresholds." + key,
                plugin.configs().punishments().getInt("default-threshold", 10));
        if (vl >= threshold) {
            Map<String, Double> m = vls.get(p.getUniqueId());
            if (m != null) m.put(key, 0.0);

            for (String cmd : plugin.configs().punishments().getStringList("commands")) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                        cmd.replace("%player%", p.getName())
                                .replace("%check%", check)
                                .replace("%reason%", reason)
                                .replace("%vl%", String.format("%.1f", vl))
                                .replace("%info%", info == null ? "" : info));
            }

            // Webhook khi punish
            if (webhook != null) {
                webhook.send(p.getName(), check, info, vl, reason, true);
            }
        }
    }

    public Map<String, Double> getVl(UUID id) {
        return vls.getOrDefault(id, Collections.emptyMap());
    }

    public boolean toggleAlerts(UUID id) {
        if (alertsOff.remove(id)) return true;
        alertsOff.add(id);
        return false;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        vls.remove(e.getPlayer().getUniqueId());
    }
}
