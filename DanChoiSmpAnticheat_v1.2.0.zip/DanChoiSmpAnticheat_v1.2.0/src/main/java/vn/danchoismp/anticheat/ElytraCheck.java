package vn.danchoismp.anticheat;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/**
 * Anti-ElytraFly: phát hiện bay elytra với tốc độ cao mà không dùng firework gần đây,
 * hoặc đang glide mà không có elytra trang bị (packet spoof).
 */
public class ElytraCheck implements Listener {

    private static class State {
        long lastBoostMs;
        int consecutive;
        double buffer;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public ElytraCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> new State());
    }

    /** Gọi khi player dùng firework (boost). */
    public void markBoost(Player p) {
        state(p).lastBoostMs = System.currentTimeMillis();
        state(p).consecutive = 0;
    }

    @EventHandler
    public void onGlideToggle(EntityToggleGlideEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (e.isGliding()) {
            // bắt đầu glide – reset consecutive
            state(p).consecutive = 0;
        }
    }

    @EventHandler
    public void onRiptide(PlayerRiptideEvent e) {
        // riptide cũng tạo tốc độ cao hợp lệ
        state(e.getPlayer()).lastBoostMs = System.currentTimeMillis();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(org.bukkit.event.player.PlayerInteractEvent e) {
        if (e.getItem() == null) return;
        if (e.getItem().getType() != Material.FIREWORK_ROCKET) return;
        Player p = e.getPlayer();
        if (!p.isGliding()) return;
        markBoost(p);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("elytra.enabled", true)) return;

        Player p = e.getPlayer();
        if (Util.skip(plugin, p)) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (!p.isGliding()) {
            state(p).consecutive = 0;
            return;
        }

        LocationSafe from = LocationSafe.of(e.getFrom());
        LocationSafe to = LocationSafe.of(e.getTo());
        if (to == null) return;

        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        double speed = Math.sqrt(dx * dx + dy * dy + dz * dz);

        State s = state(p);
        long now = System.currentTimeMillis();
        int graceTicks = c.getInt("elytra.boost-grace-ticks", 40);
        long graceMs = graceTicks * 50L;
        boolean recentBoost = (now - s.lastBoostMs) < graceMs;

        // Check 1: đang glide mà không có elytra trên ngực
        if (c.getBoolean("elytra.require-elytra-equipped", true)) {
            ItemStack chest = p.getInventory().getChestplate();
            if (chest == null || chest.getType() != Material.ELYTRA) {
                s.buffer += 1.5;
                if (s.buffer >= c.getDouble("elytra.buffer", 3)) {
                    vm.flag(p, "ElytraFly", "glide without elytra equipped", 1.5);
                    s.buffer = 0;
                }
                return;
            }
        }

        // Check 2: tốc độ ngang cao liên tục khi không có boost gần đây
        double maxUnboosted = c.getDouble("elytra.max-unboosted-speed", 1.55);
        int needConsec = c.getInt("elytra.consecutive-ticks", 8);

        if (!recentBoost && horiz > maxUnboosted) {
            s.consecutive++;
            if (s.consecutive >= needConsec) {
                s.buffer += 1.0;
                if (s.buffer >= c.getDouble("elytra.buffer", 3)) {
                    vm.flag(p, "ElytraFly",
                            String.format("unboosted speed %.2f (max %.2f) x%d", horiz, maxUnboosted, s.consecutive),
                            1.0);
                    s.buffer = Math.max(0, s.buffer - 1.5);
                    s.consecutive = 0;
                }
            }
        } else {
            s.consecutive = Math.max(0, s.consecutive - 1);
            if (s.buffer > 0) s.buffer = Math.max(0, s.buffer - 0.15);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }

    /** Wrapper nhẹ tránh null Location. */
    private static class LocationSafe {
        final double x, y, z;
        LocationSafe(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }
        static LocationSafe of(org.bukkit.Location loc) {
            if (loc == null) return null;
            return new LocationSafe(loc.getX(), loc.getY(), loc.getZ());
        }
    }
}
