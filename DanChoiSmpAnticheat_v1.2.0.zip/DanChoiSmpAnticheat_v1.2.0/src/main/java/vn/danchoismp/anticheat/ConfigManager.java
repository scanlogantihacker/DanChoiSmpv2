package vn.danchoismp.anticheat;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

/**
 * Quản lý nhiều file config: config.yml, checks.yml, punishments.yml, webhook.yml
 */
public class ConfigManager {

    private final DanChoiSmpAnticheat plugin;
    private FileConfiguration checks;
    private FileConfiguration punishments;
    private FileConfiguration webhook;

    public ConfigManager(DanChoiSmpAnticheat plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        checks = load("checks.yml");
        punishments = load("punishments.yml");
        webhook = load("webhook.yml");
    }

    private FileConfiguration load(String name) {
        File f = new File(plugin.getDataFolder(), name);
        if (!f.exists()) {
            plugin.saveResource(name, false);
        }
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        InputStream def = plugin.getResource(name);
        if (def != null) {
            cfg.setDefaults(YamlConfiguration.loadConfiguration(
                    new InputStreamReader(def, StandardCharsets.UTF_8)));
        }
        return cfg;
    }

    public void reload() {
        loadAll();
    }

    public FileConfiguration checks() {
        return checks;
    }

    public FileConfiguration punishments() {
        return punishments;
    }

    public FileConfiguration webhook() {
        return webhook;
    }
}
