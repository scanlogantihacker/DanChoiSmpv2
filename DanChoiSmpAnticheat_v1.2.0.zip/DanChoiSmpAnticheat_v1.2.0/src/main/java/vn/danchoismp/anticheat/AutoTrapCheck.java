package vn.danchoismp.anticheat;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * AutoTrap: phát hiện đặt nhiều block bao quanh một player khác trong thời gian rất ngắn
 * (thường dùng trong crystal PvP để trap đối thủ).
 */
public class AutoTrapCheck implements Listener {

    private static class PlaceRecord {
        final long time;
        final int bx, by, bz;
        final UUID nearTarget;

        PlaceRecord(long time, int bx, int by, int bz, UUID nearTarget) {
            this.time = time;
            this.bx = bx;
            this.by = by;
            this.bz = bz;
            this.nearTarget = nearTarget;
        }
    }

    private static class State {
        final Deque<PlaceRecord> places = new ArrayDeque<>();
        long lastPlaceMs;
        double buffer;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public AutoTrapCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> new State());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("autotrap.enabled", true)) return;

        Player p = e.getPlayer();
        if (Util.skip(plugin, p)) return;

        Block b = e.getBlockPlaced();
        Material type = b.getType();
        // chỉ quan tâm block rắn dùng để trap (obsidian, crying obsidian, ender chest...)
        if (!isTrapBlock(type)) return;

        Location loc = b.getLocation();
        double maxDist = c.getDouble("autotrap.max-distance-to-target", 3.5);
        long window = c.getLong("autotrap.window-ms", 1200);
        int maxBlocks = c.getInt("autotrap.max-blocks-around-target", 6);
        long minInterval = c.getLong("autotrap.min-place-interval-ms", 40);

        // tìm player gần nhất (không phải bản thân)
        Player nearest = null;
        double nearestDist = maxDist + 0.01;
        for (Player other : p.getWorld().getPlayers()) {
            if (other.getUniqueId().equals(p.getUniqueId())) continue;
            if (other.isDead()) continue;
            double d = other.getLocation().distance(loc.clone().add(0.5, 0.5, 0.5));
            if (d < nearestDist) {
                nearestDist = d;
                nearest = other;
            }
        }
        if (nearest == null) return;

        State s = state(p);
        long now = System.currentTimeMillis();

        // place quá nhanh liên tiếp
        if (s.lastPlaceMs > 0 && now - s.lastPlaceMs < minInterval) {
            s.buffer += 0.6;
        }
        s.lastPlaceMs = now;

        UUID targetId = nearest.getUniqueId();
        s.places.addLast(new PlaceRecord(now, b.getX(), b.getY(), b.getZ(), targetId));

        // dọn record cũ
        while (!s.places.isEmpty() && now - s.places.peekFirst().time > window) {
            s.places.pollFirst();
        }

        // đếm số block đặt quanh cùng 1 target trong window
        int count = 0;
        for (PlaceRecord r : s.places) {
            if (targetId.equals(r.nearTarget)) count++;
        }

        if (count >= maxBlocks) {
            s.buffer += 1.5;
            if (s.buffer >= c.getDouble("autotrap.buffer", 2.5)) {
                vm.flag(p, "AutoTrap",
                        String.format("%d blocks around %s in %dms", count, nearest.getName(), window),
                        1.5);
                s.buffer = 0;
                s.places.clear();
            }
        } else if (s.buffer > 0) {
            s.buffer = Math.max(0, s.buffer - 0.1);
        }
    }

    private boolean isTrapBlock(Material m) {
        String n = m.name();
        return n.contains("OBSIDIAN")
                || n.contains("ENDER_CHEST")
                || n.contains("ANVIL")
                || n.contains("CRYING")
                || n.equals("RESPAWN_ANCHOR")
                || n.equals("GLOWSTONE")
                || n.contains("CONCRETE")
                || n.contains("WOOL")
                || n.contains("PLANK");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
