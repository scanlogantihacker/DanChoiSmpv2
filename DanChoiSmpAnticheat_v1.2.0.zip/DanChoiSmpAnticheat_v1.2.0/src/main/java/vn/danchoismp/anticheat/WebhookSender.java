package vn.danchoismp.anticheat;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;

/** Gửi embed Discord webhook bất đồng bộ. */
public class WebhookSender {

    private final DanChoiSmpAnticheat plugin;
    private final ExecutorService pool = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "DanChoiAC-Webhook");
        t.setDaemon(true);
        return t;
    });

    public WebhookSender(DanChoiSmpAnticheat plugin) {
        this.plugin = plugin;
    }

    public void shutdown() {
        pool.shutdownNow();
    }

    public void send(String player, String check, String info, double vl, String reason, boolean isPunish) {
        FileConfiguration wh = plugin.configs().webhook();
        if (!wh.getBoolean("enabled", false)) return;
        String url = wh.getString("url", "");
        if (url == null || url.isBlank()) return;

        boolean onFlag = wh.getBoolean("send-on-flag", false);
        boolean onPunish = wh.getBoolean("send-on-punish", true);
        if (isPunish && !onPunish) return;
        if (!isPunish && !onFlag) return;

        String username = wh.getString("username", "DanChoiAC");
        String avatar = wh.getString("avatar-url", "");
        int color = wh.getInt("color", 15158332);
        String title = wh.getString("title", "AntiCheat Alert");
        String descTpl = wh.getString("description",
                "**%player%** nghi dùng **%check%**\nVL: `%vl%` | %info%\nReason: %reason%");
        String desc = descTpl
                .replace("%player%", player)
                .replace("%check%", check)
                .replace("%vl%", String.format("%.1f", vl))
                .replace("%info%", info == null ? "" : info)
                .replace("%reason%", reason == null ? check : reason)
                .replace("%server%", Bukkit.getName());

        String content = "";
        String roleId = wh.getString("ping-role-id", "");
        if (isPunish && roleId != null && !roleId.isBlank()) {
            content = "<@&" + roleId + ">";
        }

        String json = buildJson(username, avatar, color, title, desc, content);
        pool.execute(() -> post(url, json));
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    private static String buildJson(String username, String avatar, int color,
                                    String title, String desc, String content) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        if (content != null && !content.isEmpty()) {
            sb.append("\"content\":\"").append(esc(content)).append("\",");
        }
        sb.append("\"username\":\"").append(esc(username)).append("\",");
        if (avatar != null && !avatar.isBlank()) {
            sb.append("\"avatar_url\":\"").append(esc(avatar)).append("\",");
        }
        sb.append("\"embeds\":[{");
        sb.append("\"title\":\"").append(esc(title)).append("\",");
        sb.append("\"description\":\"").append(esc(desc)).append("\",");
        sb.append("\"color\":").append(color);
        sb.append("}]}");
        return sb.toString();
    }

    private void post(String urlStr, String json) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("User-Agent", "DanChoiSmpAnticheat");
            byte[] body = json.getBytes(StandardCharsets.UTF_8);
            conn.setRequestProperty("Content-Length", String.valueOf(body.length));
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body);
            }
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) {
                plugin.getLogger().warning("Webhook HTTP " + code);
            }
            conn.disconnect();
        } catch (Exception e) {
            plugin.getLogger().warning("Webhook lỗi: " + e.getMessage());
        }
    }
}
