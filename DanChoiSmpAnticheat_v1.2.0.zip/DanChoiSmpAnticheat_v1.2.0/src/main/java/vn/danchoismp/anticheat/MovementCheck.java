package vn.danchoismp.anticheat;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.BoundingBox;

/**
 * Check di chuyển kiểu Grim (bản nhẹ, dựa trên PlayerMoveEvent):
 * Speed, Fly (dự đoán trọng lực), NoFall, Step, Jesus, NoSlow.
 * Khi có GrimAC các check này tự nhường (grim-compat.yield-overlapping-checks).
 */
public class MovementCheck implements Listener {

    private static class State {
        long exemptUntil;
        // vị trí/trạng thái tick trước
        boolean hasAir;          // đã có dy hợp lệ trong không khí
        double lastDy;
        int airTicks;
        boolean lastNear = true; // tick trước có chạm đất (server tự tính)
        int usingTicks;
        int jesusTicks;
        double speedBuf, flyBuf, nofallBuf, stepBuf, jesusBuf, noslowBuf;

        void resetAir() {
            hasAir = false;
            lastDy = 0;
            airTicks = 0;
            lastNear = true;
            usingTicks = 0;
            jesusTicks = 0;
        }
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public MovementCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> new State());
    }

    private void exempt(Player p, long ms) {
        State s = state(p);
        s.exemptUntil = Math.max(s.exemptUntil, System.currentTimeMillis() + ms);
        s.resetAir();
    }

    // ---------- các sự kiện làm vị trí/vận tốc thay đổi hợp lệ ----------
    @EventHandler public void onVel(PlayerVelocityEvent e) {
        long ms = plugin.configs().checks().getLong("movement.velocity-exempt-ms", 2000);
        exempt(e.getPlayer(), ms + Math.min(Math.max(e.getPlayer().getPing(), 0), 300));
    }
    @EventHandler public void onTp(PlayerTeleportEvent e) { exempt(e.getPlayer(), 1500); }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) { exempt(e.getPlayer(), 2000); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { exempt(e.getPlayer(), 2000); }
    @EventHandler public void onJoin(PlayerJoinEvent e) { exempt(e.getPlayer(), 3000); }
    @EventHandler public void onGm(PlayerGameModeChangeEvent e) { exempt(e.getPlayer(), 2000); }
    @EventHandler public void onFlightToggle(PlayerToggleFlightEvent e) { exempt(e.getPlayer(), 2000); }
    @EventHandler public void onRiptide(PlayerRiptideEvent e) { exempt(e.getPlayer(), 4000); }
    @EventHandler public void onGlide(EntityToggleGlideEvent e) {
        if (e.getEntity() instanceof Player) exempt((Player) e.getEntity(), 3000);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("movement.enabled", true) || plugin.yieldToGrim()) return;

        Player p = e.getPlayer();
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null || from.getWorld() == null || !from.getWorld().equals(to.getWorld())) return;

        State s = state(p);
        long now = System.currentTimeMillis();

        GameMode gm = p.getGameMode();
        if (now < s.exemptUntil || Util.skip(plugin, p)
                || gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR
                || p.getAllowFlight() || p.isFlying() || p.isGliding() || p.isRiptiding()
                || p.isInsideVehicle() || p.isDead() || p.isSleeping()) {
            s.resetAir();
            return;
        }

        double dx = to.getX() - from.getX();
        double dy = to.getY() - from.getY();
        double dz = to.getZ() - from.getZ();
        double horiz = Math.hypot(dx, dz);

        // hộp va chạm của người chơi tại vị trí MỚI
        BoundingBox box = p.getBoundingBox().shift(dx, dy, dz);
        boolean solid = Util.solidNear(to.getWorld(), box);
        boolean special = Util.nearSpecial(to.getWorld(), box);
        boolean badEffect = Util.effectLevel(p, "LEVITATION", "SLOW_FALLING") > 0;

        boolean flag = false;
        boolean setback = c.getBoolean("movement.setback", true);

        // ================= NoFall =================
        // p.isOnGround() = cờ onGround client báo. Client báo "đang chạm đất" mà server thấy
        // cả vị trí cũ và mới đều lơ lửng => spoof onGround.
        if (c.getBoolean("movement.nofall.enabled", true) && !special && !badEffect) {
            if (p.isOnGround() && !s.lastNear && !solid && dy < -0.05 && !Util.entitySupport(p)) {
                s.nofallBuf++;
                if (s.nofallBuf >= c.getDouble("movement.nofall.buffer", 2)) {
                    vm.flag(p, "NoFall", "báo onGround khi đang rơi", 1.0);
                    flag = true;
                }
            } else {
                s.nofallBuf = Math.max(0, s.nofallBuf - 0.25);
            }
        }

        // ================= Fly (dự đoán trọng lực) =================
        if (solid || special || badEffect) {
            s.airTicks = 0;
            s.hasAir = false;
        } else {
            s.airTicks++;
            if (c.getBoolean("movement.fly.enabled", true) && s.hasAir && s.airTicks > 2) {
                double predicted = (s.lastDy - 0.08) * 0.98;
                double tol = c.getDouble("movement.fly.tolerance", 0.04);
                if (dy > predicted + tol && !Util.entitySupport(p)) {
                    s.flyBuf++;
                    if (s.flyBuf >= c.getDouble("movement.fly.buffer", 3)) {
                        vm.flag(p, "Fly", String.format("dy %.3f / dự kiến %.3f", dy, predicted), 1.0);
                        flag = true;
                    }
                } else {
                    s.flyBuf = Math.max(0, s.flyBuf - 0.25);
                }
            }
            s.hasAir = true;
        }

        // ================= Step =================
        if (c.getBoolean("movement.step.enabled", true) && s.lastNear && !special && !badEffect) {
            int jump = Util.effectLevel(p, "JUMP_BOOST", "JUMP");
            double limit = Math.max(0.6, 0.42 + 0.1 * jump) + c.getDouble("movement.step.tolerance", 0.05);
            if (dy > limit) {
                s.stepBuf++;
                if (s.stepBuf >= c.getDouble("movement.step.buffer", 2)) {
                    vm.flag(p, "Step", String.format("lên %.2f block", dy), 1.0);
                    flag = true;
                }
            } else {
                s.stepBuf = Math.max(0, s.stepBuf - 0.25);
            }
        }

        // ================= Speed =================
        if (c.getBoolean("movement.speed.enabled", true) && !special) {
            double limit = c.getDouble("movement.speed.base", 0.42)
                    * (p.getWalkSpeed() / 0.2)
                    * (1.0 + 0.2 * Util.effectLevel(p, "SPEED"));
            if (hasSoulSpeed(p)) limit *= 1.6;
            if (Util.onIce(to.getWorld(), box)) limit *= 2.2;
            limit += Util.lagTolerance(p) * 0.15;
            if (horiz > limit) {
                s.speedBuf++;
                if (s.speedBuf >= c.getDouble("movement.speed.buffer", 5)) {
                    vm.flag(p, "Speed", String.format("%.3f / tối đa %.3f", horiz, limit), 1.0);
                    flag = true;
                }
            } else {
                s.speedBuf = Math.max(0, s.speedBuf - 0.5);
            }
        }

        // ================= NoSlow =================
        if (c.getBoolean("movement.noslow.enabled", true) && !special) {
            if (p.isHandRaised() || p.isBlocking()) s.usingTicks++; else s.usingTicks = 0;
            if (s.usingTicks >= 8 && !Util.onIce(to.getWorld(), box)) {
                if (horiz > c.getDouble("movement.noslow.max", 0.13)) {
                    s.noslowBuf++;
                    if (s.noslowBuf >= c.getDouble("movement.noslow.buffer", 5)) {
                        vm.flag(p, "NoSlow", String.format("di chuyển %.3f khi dùng item", horiz), 1.0);
                        flag = true;
                    }
                } else {
                    s.noslowBuf = Math.max(0, s.noslowBuf - 0.5);
                }
            }
        } else {
            s.usingTicks = 0;
        }

        // ================= Jesus (đi trên nước) =================
        if (c.getBoolean("movement.jesus.enabled", true)) {
            Block feet = to.getBlock();
            Block below = to.clone().subtract(0, 0.3, 0).getBlock();
            boolean waterWalk = below.isLiquid() && !feet.isLiquid() && feet.isPassable()
                    && !solid && Math.abs(dy) < 0.005 && horiz > 0.05;
            if (waterWalk && !Util.entitySupport(p)) {
                s.jesusTicks++;
                if (s.jesusTicks >= c.getInt("movement.jesus.ticks", 6)) {
                    vm.flag(p, "Jesus", "đi trên mặt nước", 1.0);
                    flag = true;
                }
            } else {
                s.jesusTicks = 0;
            }
        }

        if (flag) {
            if (setback) e.setCancelled(true); // kéo người chơi về vị trí cũ
            // không cập nhật trạng thái tick bị flag
            s.lastNear = true;
            s.hasAir = false;
            return;
        }

        s.lastDy = dy;
        s.lastNear = solid || special;
    }

    private boolean hasSoulSpeed(Player p) {
        ItemStack boots = p.getInventory().getBoots();
        if (boots == null) return false;
        Enchantment en = Enchantment.getByKey(NamespacedKey.minecraft("soul_speed"));
        return en != null && boots.containsEnchantment(en);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
