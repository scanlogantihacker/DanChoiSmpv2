package vn.danchoismp.anticheat;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.util.BoundingBox;

/**
 * Check đặt block kiểu Grim (FarPlace / RotationPlace) + FastPlace (scaffold/nuker đặt quá nhanh).
 * Nhường cho GrimAC khi có (grim-compat.yield-overlapping-checks).
 */
public class PlaceCheck implements Listener {

    private static class State {
        final Deque<Long> places = new ArrayDeque<>();
        double farBuf, rotBuf;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public PlaceCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("place.enabled", true) || plugin.yieldToGrim()) return;
        Player p = e.getPlayer();
        if (Util.skip(plugin, p)) return;

        State s = states.computeIfAbsent(p.getUniqueId(), k -> new State());
        Location eye = p.getEyeLocation();
        Block against = e.getBlockAgainst();
        BoundingBox box = against.getBoundingBox();
        double lag = Util.lagTolerance(p);
        boolean cancel = false;

        // ---- FarPlace: đặt xa quá tầm ----
        double max = p.getGameMode() == GameMode.CREATIVE
                ? c.getDouble("place.max-reach-creative", 7.0)
                : c.getDouble("place.max-reach", 5.5);
        double dist = Util.distanceToBox(eye, box);
        if (dist > max + lag) {
            s.farBuf++;
            if (s.farBuf >= c.getDouble("place.far-buffer", 2)) {
                vm.flag(p, "FarPlace", String.format("%.2f block", dist), 1.5);
                cancel = true;
            }
        } else {
            s.farBuf = Math.max(0, s.farBuf - 0.25);
        }

        // ---- RotationPlace: không nhìn vào block đang đặt lên ----
        if (c.getBoolean("place.rotation.enabled", true) && !box.contains(eye.toVector())) {
            double expand = c.getDouble("place.rotation.expand", 0.3) + lag * 0.5;
            if (box.clone().expand(expand).rayTrace(eye.toVector(), eye.getDirection(), max + 2) == null) {
                s.rotBuf++;
                if (s.rotBuf >= c.getDouble("place.rotation.buffer", 3)) {
                    vm.flag(p, "RotationPlace", "không nhìn vào block", 1.5);
                    cancel = true;
                }
            } else {
                s.rotBuf = Math.max(0, s.rotBuf - 0.5);
            }
        }

        // ---- FastPlace ----
        long now = System.currentTimeMillis();
        s.places.addLast(now);
        while (!s.places.isEmpty() && now - s.places.peekFirst() > 1000) s.places.pollFirst();
        if (s.places.size() > c.getInt("place.max-per-second", 16)) {
            vm.flag(p, "FastPlace", s.places.size() + " block/s", 1.0);
            cancel = true;
        }

        if (cancel && c.getBoolean("place.cancel", true)) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
