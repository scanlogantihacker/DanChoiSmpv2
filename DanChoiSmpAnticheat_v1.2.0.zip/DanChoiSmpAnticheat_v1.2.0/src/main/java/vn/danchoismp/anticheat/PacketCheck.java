package vn.danchoismp.anticheat;

import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.protocol.player.User;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * KillAura / autoclicker theo packet tấn công.
 * Không đếm ANIMATION (đào, đặt, vung hụt) để khỏi báo nhầm người đào nhanh.
 */
public class PacketCheck extends PacketListenerAbstract implements Listener {

    private static class State {
        final Deque<Long> attacks = new ArrayDeque<>();
        final Deque<Double> intervals = new ArrayDeque<>();
        final Deque<Long> multiHits = new ArrayDeque<>();
        int lastTargetId = -1;
        long lastAttackNs;
        double clickBuf;
        double multiBuf;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final ConcurrentHashMap<UUID, State> states = new ConcurrentHashMap<>();

    public PacketCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        super(PacketListenerPriority.NORMAL);
        this.plugin = plugin;
        this.vm = vm;
    }

    @Override
    public void onPacketReceive(PacketReceiveEvent event) {
        if (event.getPacketType() != PacketType.Play.Client.INTERACT_ENTITY) return;

        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("packets.enabled", true)) return;

        User user = event.getUser();
        UUID id = user.getUUID();
        if (id == null) return;
        Player p = Bukkit.getPlayer(id);
        if (p == null || Util.skip(plugin, p)) return;

        WrapperPlayClientInteractEntity w = new WrapperPlayClientInteractEntity(event);
        if (w.getAction() != WrapperPlayClientInteractEntity.InteractAction.ATTACK) return;

        State s = states.computeIfAbsent(id, k -> new State());
        long nowMs = System.currentTimeMillis();
        long nowNs = System.nanoTime();
        int targetId = w.getEntityId();
        boolean cancel = false;

        synchronized (s) {
            if (c.getBoolean("packets.multi-target.enabled", true)
                    && s.lastTargetId != -1 && s.lastTargetId != targetId && s.lastAttackNs != 0) {
                double gapMs = (nowNs - s.lastAttackNs) / 1_000_000.0;
                if (gapMs >= 0 && gapMs < c.getDouble("packets.multi-target.window-ms", 12)) {
                    s.multiHits.addLast(nowMs);
                    long window = c.getLong("packets.multi-target.repeat-window-ms", 2000);
                    while (!s.multiHits.isEmpty() && nowMs - s.multiHits.peekFirst() > window) s.multiHits.pollFirst();
                    int need = c.getInt("packets.multi-target.buffer", 3);
                    if (s.multiHits.size() >= need) {
                        vm.flag(p, "KillAura", String.format("multi-target %.0fms x%d", gapMs, s.multiHits.size()), 1.0);
                        s.multiHits.clear();
                        cancel = true;
                    }
                }
            }

            s.attacks.addLast(nowMs);
            while (!s.attacks.isEmpty() && nowMs - s.attacks.peekFirst() > 1000) s.attacks.pollFirst();
            int maxAps = c.getInt("packets.max-attacks-per-second", 16);
            if (s.attacks.size() > maxAps) {
                s.clickBuf++;
                if (s.clickBuf >= c.getDouble("packets.autoclicker.buffer", 2)) {
                    vm.flag(p, "KillAura", s.attacks.size() + " đòn/s", 1.0);
                    s.clickBuf = 0;
                    cancel = true;
                }
            } else {
                s.clickBuf = Math.max(0, s.clickBuf - 0.25);
            }

            if (s.lastAttackNs != 0) {
                double gapMs = (nowNs - s.lastAttackNs) / 1_000_000.0;
                if (gapMs > 25 && gapMs < 250) {
                    s.intervals.addLast(gapMs);
                    int samples = c.getInt("packets.autoclicker.samples", 40);
                    while (s.intervals.size() > samples) s.intervals.pollFirst();
                    if (s.intervals.size() >= samples) {
                        double mean = 0;
                        for (double v : s.intervals) mean += v;
                        mean /= s.intervals.size();
                        double var = 0;
                        for (double v : s.intervals) var += (v - mean) * (v - mean);
                        double std = Math.sqrt(var / s.intervals.size());
                        if (std < c.getDouble("packets.autoclicker.regular-std-ms", 3.5) && mean < 120) {
                            vm.flag(p, "KillAura", String.format("nhịp máy ~%.0fms (σ=%.1f)", mean, std), 1.0);
                            s.intervals.clear();
                            cancel = true;
                        }
                    }
                } else if (gapMs >= 250) {
                    s.intervals.clear();
                }
            }

            s.lastTargetId = targetId;
            s.lastAttackNs = nowNs;
            if (cancel && c.getBoolean("combat.cancel-hits", true)) event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
