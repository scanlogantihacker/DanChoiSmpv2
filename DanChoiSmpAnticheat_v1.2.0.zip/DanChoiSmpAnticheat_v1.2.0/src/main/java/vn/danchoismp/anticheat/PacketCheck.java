package vn.danchoismp.anticheat;

import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
import com.github.retrooper.packetevents.protocol.player.User;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Check bằng packet (thời gian chính xác theo từng packet, không bị gộp theo tick):
 *  - KillAura: đánh 2 mục tiêu khác nhau trong cực ngắn, quá nhiều đòn/giây
 *  - AutoClicker: CPS quá cao, khoảng cách giữa các đòn đều tăm tắp
 */
public class PacketCheck extends PacketListenerAbstract implements Listener {

    private static class State {
        final Deque<Long> swings = new ArrayDeque<>();   // ms
        final Deque<Long> attacks = new ArrayDeque<>();  // ms
        final Deque<Double> intervals = new ArrayDeque<>();
        int lastTargetId = -1;
        long lastAttackNs;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final ConcurrentHashMap<UUID, State> states = new ConcurrentHashMap<>();

    public PacketCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        super(PacketListenerPriority.NORMAL);
        this.plugin = plugin;
        this.vm = vm;
    }

    @Override
    public void onPacketReceive(PacketReceiveEvent event) {
        PacketTypeCommon type = event.getPacketType();
        boolean swing = type == PacketType.Play.Client.ANIMATION;
        boolean interact = type == PacketType.Play.Client.INTERACT_ENTITY;
        if (!swing && !interact) return;

        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("packets.enabled", true)) return;

        User user = event.getUser();
        UUID id = user.getUUID();
        if (id == null) return;
        Player p = Bukkit.getPlayer(id);
        if (p == null || Util.skip(plugin, p)) return;

        State s = states.computeIfAbsent(id, k -> new State());
        long nowMs = System.currentTimeMillis();
        long nowNs = System.nanoTime();

        synchronized (s) {
            if (swing) {
                s.swings.addLast(nowMs);
                while (!s.swings.isEmpty() && nowMs - s.swings.peekFirst() > 1000) s.swings.pollFirst();
                int maxCps = c.getInt("packets.autoclicker.max-cps", 25);
                if (s.swings.size() > maxCps) {
                    vm.flag(p, "KillAura", "autoclick " + s.swings.size() + " CPS", 1.0);
                }
                return;
            }

            WrapperPlayClientInteractEntity w = new WrapperPlayClientInteractEntity(event);
            if (w.getAction() != WrapperPlayClientInteractEntity.InteractAction.ATTACK) return;
            int targetId = w.getEntityId();
            boolean cancel = false;

            // 1) đánh 2 mục tiêu khác nhau quá nhanh
            if (c.getBoolean("packets.multi-target.enabled", true)
                    && s.lastTargetId != -1 && s.lastTargetId != targetId) {
                double gapMs = (nowNs - s.lastAttackNs) / 1_000_000.0;
                if (gapMs < c.getDouble("packets.multi-target.window-ms", 40)) {
                    vm.flag(p, "KillAura", String.format("multi-target %.0fms", gapMs), 2.0);
                    cancel = true;
                }
            }

            // 2) quá nhiều đòn mỗi giây
            s.attacks.addLast(nowMs);
            while (!s.attacks.isEmpty() && nowMs - s.attacks.peekFirst() > 1000) s.attacks.pollFirst();
            if (s.attacks.size() > c.getInt("packets.max-attacks-per-second", 22)) {
                vm.flag(p, "KillAura", s.attacks.size() + " đòn/s", 1.0);
                cancel = true;
            }

            // 3) nhịp đánh đều tăm tắp (autoclicker)
            if (s.lastAttackNs != 0) {
                double gapMs = (nowNs - s.lastAttackNs) / 1_000_000.0;
                if (gapMs > 20 && gapMs < 400) {
                    s.intervals.addLast(gapMs);
                    int samples = c.getInt("packets.autoclicker.samples", 30);
                    while (s.intervals.size() > samples) s.intervals.pollFirst();
                    if (s.intervals.size() >= samples) {
                        double mean = 0;
                        for (double v : s.intervals) mean += v;
                        mean /= s.intervals.size();
                        double var = 0;
                        for (double v : s.intervals) var += (v - mean) * (v - mean);
                        double std = Math.sqrt(var / s.intervals.size());
                        if (std < c.getDouble("packets.autoclicker.regular-std-ms", 6)) {
                            vm.flag(p, "KillAura", String.format("nhịp đều ~%.0fms (σ=%.1f)", mean, std), 1.5);
                            s.intervals.clear();
                        }
                    }
                } else {
                    s.intervals.clear();
                }
            }

            s.lastTargetId = targetId;
            s.lastAttackNs = nowNs;
            if (cancel && c.getBoolean("combat.cancel-hits", true)) event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
