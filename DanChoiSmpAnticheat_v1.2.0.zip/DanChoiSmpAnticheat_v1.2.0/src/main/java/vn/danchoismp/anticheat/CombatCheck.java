package vn.danchoismp.anticheat;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

/**
 * Reach + Hitbox + KillAura (góc, xuyên tường).
 * Bỏ qua đòn sweep phụ và nới hitbox theo ping/vận tốc mục tiêu để giảm báo nhầm.
 */
public class CombatCheck implements Listener {

    private static class State {
        double reachBuf, hitboxBuf, angleBuf, wallBuf;
        int tick = -1;
        int hitsThisTick;
        UUID lookedAt;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public CombatCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != DamageCause.ENTITY_ATTACK) return;
        if (!(e.getEntity() instanceof LivingEntity target)) return;
        if (target.getUniqueId().equals(p.getUniqueId()) || Util.skip(plugin, p)) return;

        FileConfiguration c = plugin.configs().checks();
        boolean grim = plugin.yieldToGrim();
        State s = states.computeIfAbsent(p.getUniqueId(), k -> new State());

        int tick = Bukkit.getCurrentTick();
        if (s.tick != tick) {
            s.tick = tick;
            s.hitsThisTick = 0;
            s.lookedAt = null;
        }
        s.hitsThisTick++;

        Location eye = p.getEyeLocation();
        Vector eyeDir = eye.getDirection();
        BoundingBox box = target.getBoundingBox();
        double dist = Util.distanceToBox(eye, box);
        double angle = Util.angleDeg(eyeDir, box.getCenter().subtract(eye.toVector()));

        // Đòn sweep / đánh nhiều mob cùng tick: mục tiêu không nằm trên tầm nhìn thì bỏ qua.
        boolean sweep = s.hitsThisTick > 1 && (s.lookedAt == null || !s.lookedAt.equals(target.getUniqueId()));
        if (angle < 55) s.lookedAt = target.getUniqueId();
        if (sweep) return;

        double lag = Util.lagTolerance(p);
        int victimPing = target instanceof Player vp ? Math.max(0, Math.min(vp.getPing(), 300)) : 0;
        double rewind = (lag + victimPing / 1000.0 * 4.0) + target.getVelocity().length() * 0.45;
        double tol = c.getDouble("combat.lag-base-tolerance", 0.3) + lag;
        boolean cancel = false;

        if (!grim && c.getBoolean("combat.reach.enabled", true)) {
            double max = p.getGameMode() == GameMode.CREATIVE
                    ? c.getDouble("combat.reach.max-creative", 6.0)
                    : c.getDouble("combat.reach.max", 3.1);
            if (dist > max + tol + rewind * 0.35) {
                s.reachBuf++;
                if (s.reachBuf >= c.getDouble("combat.reach.buffer", 4)) {
                    vm.flag(p, "Reach", String.format("%.2f block", dist), 1.0);
                    s.reachBuf = Math.max(0, s.reachBuf - 2);
                    cancel = true;
                }
            } else {
                s.reachBuf = Math.max(0, s.reachBuf - 0.5);
            }
        }

        double expand = c.getDouble("combat.hitbox.expand", 0.35) + rewind;
        BoundingBox wide = box.clone().expand(expand, expand * 0.6, expand);
        boolean inside = wide.contains(eye.toVector());
        boolean rayHit = inside || wide.rayTrace(eye.toVector(), eyeDir, Math.max(dist, 0.5) + expand + 1.5) != null;
        double minDist = c.getDouble("combat.hitbox.min-distance", 2.6);

        if (!grim && c.getBoolean("combat.hitbox.enabled", true) && !inside && dist > minDist) {
            double toBox = Util.angleDeg(eyeDir, Util.closestPoint(eye, wide).subtract(eye.toVector()));
            double minAngle = c.getDouble("combat.hitbox.min-angle", 38);
            if (!rayHit && toBox > minAngle) {
                s.hitboxBuf++;
                if (s.hitboxBuf >= c.getDouble("combat.hitbox.buffer", 5)) {
                    vm.flag(p, "Hitbox", String.format("lệch %.0f° / %.2f block", toBox, dist), 1.0);
                    s.hitboxBuf = Math.max(0, s.hitboxBuf - 2);
                    cancel = true;
                }
            } else {
                s.hitboxBuf = Math.max(0, s.hitboxBuf - 0.75);
            }
        } else {
            s.hitboxBuf = Math.max(0, s.hitboxBuf - 0.25);
        }

        if (!grim && c.getBoolean("combat.killaura.angle.enabled", true)) {
            double maxAng = c.getDouble("combat.killaura.angle.max-degrees", 115);
            double angMinDist = c.getDouble("combat.killaura.angle.min-distance", 2.4);
            if (dist > angMinDist && angle > maxAng && !rayHit) {
                s.angleBuf++;
                if (s.angleBuf >= c.getDouble("combat.killaura.angle.buffer", 4)) {
                    vm.flag(p, "KillAura", "góc lệch " + (int) angle + "°", 1.0);
                    s.angleBuf = Math.max(0, s.angleBuf - 2);
                    cancel = true;
                }
            } else {
                s.angleBuf = Math.max(0, s.angleBuf - 0.5);
            }
        }

        if (c.getBoolean("combat.killaura.wall.enabled", true)) {
            double wallMin = c.getDouble("combat.killaura.wall.min-distance", 2.2);
            if (dist > wallMin && !inside && Util.fullyWalled(eye, box)) {
                s.wallBuf++;
                if (s.wallBuf >= c.getDouble("combat.killaura.wall.buffer", 4)) {
                    vm.flag(p, "KillAura", "đánh xuyên tường", 1.0);
                    s.wallBuf = Math.max(0, s.wallBuf - 2);
                    cancel = true;
                }
            } else {
                s.wallBuf = Math.max(0, s.wallBuf - 0.5);
            }
        }

        if (cancel && c.getBoolean("combat.cancel-hits", true)) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
