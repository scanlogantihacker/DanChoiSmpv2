package vn.danchoismp.anticheat;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Auto TNT Minecart. Chỉ flag nhịp cùng tick (macro), không flag người đặt tay nhanh.
 */
public class CartCheck implements Listener {

    private static class State {
        long lastRail, lastSwitch;
        final Deque<Long> carts = new ArrayDeque<>();
        double buffer;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public CartCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> new State());
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwitch(PlayerItemHeldEvent e) {
        state(e.getPlayer()).lastSwitch = System.currentTimeMillis();
    }

    @EventHandler(ignoreCancelled = true)
    public void onRail(BlockPlaceEvent e) {
        if (Util.isRail(e.getBlockPlaced().getType())) {
            state(e.getPlayer()).lastRail = System.currentTimeMillis();
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCart(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getItem() == null) return;
        if (e.getItem().getType() != Material.TNT_MINECART) return;
        if (e.getClickedBlock() == null || !Util.isRail(e.getClickedBlock().getType())) return;

        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("cart.enabled", true)) return;
        Player p = e.getPlayer();
        if (Util.skip(plugin, p)) return;

        State s = state(p);
        long now = System.currentTimeMillis();
        s.carts.addLast(now);
        while (!s.carts.isEmpty() && now - s.carts.peekFirst() > 2000) s.carts.pollFirst();

        String info = null;
        if (s.lastRail > 0) {
            long railDelta = now - s.lastRail;
            long maxRail = c.getLong("cart.min-rail-to-cart-ms", 40);
            if (railDelta >= 0 && railDelta < maxRail) {
                info = "ray → cart " + railDelta + "ms";
            }
        }
        if (info == null && s.lastSwitch > 0 && s.lastRail > 0) {
            long switchDelta = now - s.lastSwitch;
            long railDelta = now - s.lastRail;
            long maxSwitch = c.getLong("cart.min-switch-to-use-ms", 25);
            // Đổi slot rồi đặt cart ngay, và ray cũng vừa đặt — chữ ký autocart, không phải scroll hotbar thường.
            if (switchDelta >= 0 && switchDelta < maxSwitch && railDelta >= 0 && railDelta < 250) {
                info = "đổi slot → cart " + switchDelta + "ms";
            }
        }
        int maxCarts = c.getInt("cart.max-carts-per-2s", 5);
        if (info == null && s.carts.size() > maxCarts) {
            info = s.carts.size() + " cart/2s";
        }

        if (info != null) {
            s.buffer++;
            if (s.buffer >= c.getDouble("cart.buffer", 3)) {
                vm.flag(p, "AutoCart", info, 1.0);
                s.buffer = Math.max(0, s.buffer - 2);
                if (c.getBoolean("cart.cancel", true)) e.setCancelled(true);
            }
        } else {
            s.buffer = Math.max(0, s.buffer - 0.5);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
