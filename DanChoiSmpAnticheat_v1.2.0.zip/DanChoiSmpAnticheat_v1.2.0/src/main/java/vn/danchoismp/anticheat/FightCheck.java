package vn.danchoismp.anticheat;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Fight: giật aim lớn trong một tick rồi đánh ngay, lặp lại.
 * Flick chuột thật thỉnh thoảng không đủ số lần trong cửa sổ thời gian.
 */
public class FightCheck implements Listener {

    private static class State {
        float lastYaw, lastPitch;
        boolean hasRot;
        long lastRotMs;
        float snapYaw, snapPitch;
        final Deque<Long> snaps = new ArrayDeque<>();
        double buffer;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public FightCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> new State());
    }

    private static float wrap(float d) {
        while (d > 180) d -= 360;
        while (d < -180) d += 360;
        return d;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        if (to == null) return;
        Location from = e.getFrom();
        float dyaw = Math.abs(wrap(to.getYaw() - from.getYaw()));
        float dpitch = Math.abs(to.getPitch() - from.getPitch());
        if (dyaw < 1 && dpitch < 1) return;

        State s = state(e.getPlayer());
        s.lastYaw = to.getYaw();
        s.lastPitch = to.getPitch();
        s.snapYaw = dyaw;
        s.snapPitch = dpitch;
        s.lastRotMs = System.currentTimeMillis();
        s.hasRot = true;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != DamageCause.ENTITY_ATTACK) return;
        if (!(e.getEntity() instanceof LivingEntity target)) return;
        if (Util.skip(plugin, p)) return;

        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("fight.enabled", true)) return;

        State s = state(p);
        if (!s.hasRot) return;
        long now = System.currentTimeMillis();
        long age = now - s.lastRotMs;
        if (age < 0 || age > c.getLong("fight.max-rot-age-ms", 80)) return;

        double snap = Math.hypot(s.snapYaw, s.snapPitch);
        double minSnap = c.getDouble("fight.min-snap-degrees", 35);
        if (snap < minSnap) return;

        double dist = p.getEyeLocation().distance(target.getLocation().add(0, target.getHeight() * 0.5, 0));
        if (dist < c.getDouble("fight.min-distance", 1.8)) return;

        s.snaps.addLast(now);
        long window = c.getLong("fight.window-ms", 3000);
        while (!s.snaps.isEmpty() && now - s.snaps.peekFirst() > window) s.snaps.pollFirst();

        int need = c.getInt("fight.snaps-in-window", 5);
        if (s.snaps.size() >= need) {
            vm.flag(p, "Fight", String.format("giật %.0f° rồi đánh, %d lần", snap, s.snaps.size()), 1.0);
            s.snaps.clear();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
