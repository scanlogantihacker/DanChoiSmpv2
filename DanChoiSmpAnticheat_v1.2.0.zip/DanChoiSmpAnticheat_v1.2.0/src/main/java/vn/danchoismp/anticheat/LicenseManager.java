package vn.danchoismp.anticheat;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Kiểm tra key kích hoạt: DanChoiSmpKey1 ... DanChoiSmpKey10.
 * Chỉ lưu mã băm SHA-256 nên không lộ key dạng chữ trong jar.
 * Hỗ trợ đọc key từ folder key/key.txt khi chưa có trong config.
 */
public final class LicenseManager {

    private static final Set<String> HASHES = Set.of(
            "810faa72f6b98be546d434668a9e526d7cd866dba3e934bf1a5194093ef7ba64", // Key1
            "65a466f90764ccdd898b44843107534ca39b72d25717c010de29fc4fd5f63264", // Key2
            "3e9348c71a06dc6af967fb3e363fbf4530d5fc5de2799cac2df4f16c174485fb", // Key3
            "69bf10be726618d0778e9603db3c4c3411a0fa951680d5c2ffe6a45dea0d943b", // Key4
            "f62e7fdfa7df940bfed74d20cc737a4ffaec4e9efbd9e6cd7d06d787ecb55aab", // Key5
            "a0e3457bc5a60e1c074a1430ca2e14d38a60b47d3c9b26ee11e9eb25e3d14faa", // Key6
            "6ae1a41a23cff54a78c0e9eaf480f1816be7425673cd5fc88a36d30207ec49a1", // Key7
            "9959bbb27607c8235d7a7dc9f84994050f176ec2220b7888db6e1306fb12dda7", // Key8
            "1576eb6ecafa017c549599c2dc4641cfd098b2415627f46ccdf3c8d78af6b475", // Key9
            "e4fe93d9eba56a32a606b9070fd169a594dd3de1eb6482abda54533e609cabd8"  // Key10
    );

    private LicenseManager() {}

    public static boolean valid(String key) {
        if (key == null) return false;
        String k = key.trim();
        if (k.isEmpty()) return false;
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(k.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return HASHES.contains(sb.toString());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Tạo folder key/ và file key.txt (hướng dẫn) nếu chưa có key hợp lệ.
     * Trả về key đọc được từ key/key.txt (có thể rỗng).
     */
    public static String ensureKeyFolder(File dataFolder, Logger log) {
        File keyDir = new File(dataFolder, "key");
        if (!keyDir.exists() && !keyDir.mkdirs()) {
            log.warning("Không tạo được folder key/");
            return "";
        }
        File keyFile = new File(keyDir, "key.txt");
        if (!keyFile.exists()) {
            try {
                String guide = "# Ghi key kích hoạt vào dòng bên dưới (chỉ 1 dòng, không có khoảng trắng thừa)\n"
                        + "# Ví dụ: DanChoiSmpKey1\n"
                        + "# Sau khi ghi xong, restart server hoặc /ac reload\n"
                        + "\n";
                Files.writeString(keyFile.toPath(), guide, StandardCharsets.UTF_8);
                log.info("Đã tạo folder key/ và file key/key.txt — hãy ghi key vào đó rồi restart.");
            } catch (Exception e) {
                log.warning("Không tạo được key/key.txt: " + e.getMessage());
            }
            return "";
        }
        try {
            for (String line : Files.readAllLines(keyFile.toPath(), StandardCharsets.UTF_8)) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                return line;
            }
        } catch (Exception e) {
            log.warning("Không đọc được key/key.txt: " + e.getMessage());
        }
        return "";
    }
}
