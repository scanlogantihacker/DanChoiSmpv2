package vn.danchoismp.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.World;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class Util {

    private Util() {}

    /** Bỏ qua người có quyền bypass, spectator, hoặc khi server đang lag. */
    public static boolean skip(DanChoiSmpAnticheat plugin, Player p) {
        if (!plugin.isLicensed()) return true;
        if (p.hasPermission("anticheat.bypass")) return true;
        if (p.getGameMode() == GameMode.SPECTATOR) return true;
        return Bukkit.getTPS()[0] < plugin.getConfig().getDouble("min-tps", 17.0);
    }

    /** Dung sai (block) tăng theo ping, tối đa tính tới 300ms. */
    public static double lagTolerance(Player p) {
        int ping = Math.max(0, Math.min(p.getPing(), 300));
        return ping / 1000.0 * 4.0;
    }

    /** Khoảng cách từ mắt tới điểm gần nhất của hitbox. */
    public static double distanceToBox(Location eye, BoundingBox b) {
        double dx = Math.max(Math.max(b.getMinX() - eye.getX(), 0), eye.getX() - b.getMaxX());
        double dy = Math.max(Math.max(b.getMinY() - eye.getY(), 0), eye.getY() - b.getMaxY());
        double dz = Math.max(Math.max(b.getMinZ() - eye.getZ(), 0), eye.getZ() - b.getMaxZ());
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static boolean blocked(Location eye, Vector point) {
        Vector dir = point.clone().subtract(eye.toVector());
        double len = dir.length();
        if (len < 0.5) return false;
        RayTraceResult r = eye.getWorld().rayTraceBlocks(eye, dir.normalize(), len,
                FluidCollisionMode.NEVER, true);
        return r != null && r.getHitBlock() != null && r.getHitBlock().getType().isOccluding();
    }

    /** True nếu mọi điểm mẫu trên hitbox đều bị block đặc che. */
    public static boolean wallBetween(Location eye, BoundingBox box) {
        return fullyWalled(eye, box);
    }

    /** True chỉ khi mọi điểm mẫu trên hitbox đều bị block đặc che. Một góc lộ ra là không tính. */
    public static boolean fullyWalled(Location eye, BoundingBox box) {
        double minX = box.getMinX() + 0.05, maxX = box.getMaxX() - 0.05;
        double minY = box.getMinY() + 0.1, maxY = box.getMaxY() - 0.1;
        double minZ = box.getMinZ() + 0.05, maxZ = box.getMaxZ() - 0.05;
        double cx = box.getCenterX(), cy = box.getCenterY(), cz = box.getCenterZ();
        Vector[] pts = {
                new Vector(cx, cy, cz),
                new Vector(cx, maxY, cz),
                new Vector(cx, minY, cz),
                new Vector(minX, cy, minZ),
                new Vector(maxX, cy, minZ),
                new Vector(minX, cy, maxZ),
                new Vector(maxX, cy, maxZ)
        };
        for (Vector p : pts) {
            if (!blocked(eye, p)) return false;
        }
        return true;
    }

    /** Điểm trên hộp gần mắt nhất. */
    public static Vector closestPoint(Location eye, BoundingBox b) {
        double x = clamp(eye.getX(), b.getMinX(), b.getMaxX());
        double y = clamp(eye.getY(), b.getMinY(), b.getMaxY());
        double z = clamp(eye.getZ(), b.getMinZ(), b.getMaxZ());
        return new Vector(x, y, z);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Góc (độ) giữa hướng nhìn và một vector. */
    public static double angleDeg(Vector dir, Vector to) {
        if (to.lengthSquared() < 1.0E-6 || dir.lengthSquared() < 1.0E-6) return 0;
        return Math.toDegrees(dir.angle(to));
    }

    /** Đang ở môi trường làm knockback bị sai lệch (nước, mạng nhện, thang...). */
    public static boolean specialEnvironment(Player p) {
        return special(p.getLocation().getBlock()) || special(p.getEyeLocation().getBlock());
    }

    private static boolean special(Block b) {
        if (b.isLiquid()) return true;
        String n = b.getType().name();
        return n.contains("WEB") || n.contains("LADDER") || n.contains("VINE")
                || n.contains("SCAFFOLDING") || n.contains("BERRY") || n.contains("POWDER_SNOW")
                || n.contains("HONEY") || n.contains("BUBBLE");
    }

    /** Có block đặc chắn trên đường knockback không. */
    public static boolean pathBlocked(Location start, Vector dir) {
        for (double d = 0.7; d <= 2.8; d += 0.7) {
            Location l = start.clone().add(dir.getX() * d, 0, dir.getZ() * d);
            if (l.getBlock().getType().isSolid()
                    || l.clone().add(0, 1, 0).getBlock().getType().isSolid()) return true;
        }
        return false;
    }

    public static boolean isRail(Material m) {
        return m == Material.RAIL || m == Material.POWERED_RAIL
                || m == Material.DETECTOR_RAIL || m == Material.ACTIVATOR_RAIL;
    }

    // ===================== Helper cho check di chuyển =====================

    /** Cấp độ effect (0 = không có, 1 = level I...). Thử nhiều tên để chạy được nhiều phiên bản. */
    public static int effectLevel(Player p, String... names) {
        for (String n : names) {
            PotionEffectType t = PotionEffectType.getByName(n);
            if (t == null) continue;
            PotionEffect e = p.getPotionEffect(t);
            if (e != null) return e.getAmplifier() + 1;
        }
        return 0;
    }

    /** Có block đặc (có va chạm) ngay dưới/quanh chân trong phạm vi 0.5 block không. */
    public static boolean solidNear(World w, BoundingBox b) {
        double x0 = b.getMinX() - 0.05, x1 = b.getMaxX() + 0.05;
        double z0 = b.getMinZ() - 0.05, z1 = b.getMaxZ() + 0.05;
        double y0 = b.getMinY() - 0.5, y1 = b.getMinY() + 0.05;
        BoundingBox probe = new BoundingBox(x0, y0, z0, x1, y1, z1);
        for (int x = (int) Math.floor(x0); x <= (int) Math.floor(x1); x++) {
            for (int y = (int) Math.floor(y0); y <= (int) Math.floor(y1); y++) {
                for (int z = (int) Math.floor(z0); z <= (int) Math.floor(z1); z++) {
                    Block bl = w.getBlockAt(x, y, z);
                    if (bl.isPassable()) continue;
                    if (bl.getBoundingBox().overlaps(probe)) return true;
                }
            }
        }
        return false;
    }

    /** Đứng trên boat / shulker / minecart. */
    public static boolean entitySupport(Player p) {
        for (Entity e : p.getNearbyEntities(1.3, 1.6, 1.3)) {
            if (e instanceof Boat || e instanceof Shulker || e instanceof Minecart) return true;
        }
        return false;
    }

    private static final String[] SPECIAL = {
            "SLIME", "HONEY", "_BED", "COBWEB", "WEB", "LADDER", "VINE", "SCAFFOLDING",
            "BUBBLE", "POWDER_SNOW", "BERRY", "TWISTING", "WEEPING", "PISTON", "TRAMPOLINE",
            "WATER", "LAVA", "KELP", "SEAGRASS", "DRIPSTONE", "SOUL_SAND"
    };

    /** Có block đặc biệt (nảy, chậm, thang, nước...) trong vùng quanh người (xuống 1.2 block). */
    public static boolean nearSpecial(World w, BoundingBox b) {
        int x0 = (int) Math.floor(b.getMinX() - 0.3), x1 = (int) Math.floor(b.getMaxX() + 0.3);
        int z0 = (int) Math.floor(b.getMinZ() - 0.3), z1 = (int) Math.floor(b.getMaxZ() + 0.3);
        int y0 = (int) Math.floor(b.getMinY() - 1.2), y1 = (int) Math.floor(b.getMaxY() + 0.1);
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) {
                    Block bl = w.getBlockAt(x, y, z);
                    Material m = bl.getType();
                    if (m == Material.AIR || m == Material.CAVE_AIR || m == Material.VOID_AIR) continue;
                    if (bl.isLiquid()) return true;
                    String n = m.name();
                    for (String k : SPECIAL) if (n.contains(k)) return true;
                }
            }
        }
        return false;
    }

    /** Có băng dưới chân (băng làm tốc độ cao hơn bình thường). */
    public static boolean onIce(World w, BoundingBox b) {
        int x0 = (int) Math.floor(b.getMinX()), x1 = (int) Math.floor(b.getMaxX());
        int z0 = (int) Math.floor(b.getMinZ()), z1 = (int) Math.floor(b.getMaxZ());
        int y = (int) Math.floor(b.getMinY() - 0.6);
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int yy = y; yy <= y + 1; yy++) {
                    if (w.getBlockAt(x, yy, z).getType().name().contains("ICE")) return true;
                }
            }
        }
        return false;
    }
}
