package vn.danchoismp.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.World;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class Util {

    private Util() {}

    /** Bỏ qua người có quyền bypass, spectator, hoặc khi server đang lag. */
    public static boolean skip(DanChoiSmpAnticheat plugin, Player p) {
        if (!plugin.isLicensed()) return true;
        if (p.hasPermission("anticheat.bypass")) return true;
        if (p.getGameMode() == GameMode.SPECTATOR) return true;
        return Bukkit.getTPS()[0] < plugin.getConfig().getDouble("min-tps", 17.0);
    }

    /** Dung sai (block) tăng theo ping, tối đa tính tới 300ms. */
    public static double lagTolerance(Player p) {
        int ping = Math.max(0, Math.min(p.getPing(), 300));
        return ping / 1000.0 * 4.0;
    }

    /** Khoảng cách từ mắt tới điểm gần nhất của hitbox. */
    public static double distanceToBox(Location eye, BoundingBox b) {
        double dx = Math.max(Math.max(b.getMinX() - eye.getX(), 0), eye.getX() - b.getMaxX());
        double dy = Math.max(Math.max(b.getMinY() - eye.getY(), 0), eye.getY() - b.getMaxY());
        double dz = Math.max(Math.max(b.getMinZ() - eye.getZ(), 0), eye.getZ() - b.getMaxZ());
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static boolean blocked(Location eye, Vector point) {
        Vector dir = point.clone().subtract(eye.toVector());
        double len = dir.length();
        if (len < 0.5) return false;
        RayTraceResult r = eye.getWorld().rayTraceBlocks(eye, dir.normalize(), len,
                FluidCollisionMode.NEVER, true);
        return r != null && r.getHitBlock() != null && r.getHitBlock().getType().isOccluding();
    }

    /** True nếu cả 3 tia (giữa, đầu, chân) tới mục tiêu đều bị block chắn. */
    public static boolean wallBetween(Location eye, BoundingBox box) {
        double cx = box.getCenterX(), cz = box.getCenterZ();
        double[] ys = { box.getCenterY(), box.getMaxY() - 0.1, box.getMinY() + 0.1 };
        for (double y : ys) {
            if (!blocked(eye, new Vector(cx, y, cz))) return false;
        }
        return true;
    }

    /** Đang ở môi trường làm knockback bị sai lệch (nước, mạng nhện, thang...). */
    public static boolean specialEnvironment(Player p) {
        return special(p.getLocation().getBlock()) || special(p.getEyeLocation().getBlock());
    }

    private static boolean special(Block b) {
        if (b.isLiquid()) return true;
        String n = b.getType().name();
        return n.contains("WEB") || n.contains("LADDER") || n.contains("VINE")
                || n.contains("SCAFFOLDING") || n.contains("BERRY") || n.contains("POWDER_SNOW")
                || n.contains("HONEY") || n.contains("BUBBLE");
    }

    /** Có block đặc chắn trên đường knockback không. */
    public static boolean pathBlocked(Location start, Vector dir) {
        for (double d = 0.7; d <= 2.8; d += 0.7) {
            Location l = start.clone().add(dir.getX() * d, 0, dir.getZ() * d);
            if (l.getBlock().getType().isSolid()
                    || l.clone().add(0, 1, 0).getBlock().getType().isSolid()) return true;
        }
        return false;
    }

    public static boolean isRail(Material m) {
        return m == Material.RAIL || m == Material.POWERED_RAIL
                || m == Material.DETECTOR_RAIL || m == Material.ACTIVATOR_RAIL;
    }

    // ===================== Helper cho check di chuyển =====================

    /** Cấp độ effect (0 = không có, 1 = level I...). Thử nhiều tên để chạy được nhiều phiên bản. */
    public static int effectLevel(Player p, String... names) {
        for (String n : names) {
            PotionEffectType t = PotionEffectType.getByName(n);
            if (t == null) continue;
            PotionEffect e = p.getPotionEffect(t);
            if (e != null) return e.getAmplifier() + 1;
        }
        return 0;
    }

    /** Có block đặc (có va chạm) ngay dưới/quanh chân trong phạm vi 0.5 block không. */
    public static boolean solidNear(World w, BoundingBox b) {
        double x0 = b.getMinX() - 0.05, x1 = b.getMaxX() + 0.05;
        double z0 = b.getMinZ() - 0.05, z1 = b.getMaxZ() + 0.05;
        double y0 = b.getMinY() - 0.5, y1 = b.getMinY() + 0.05;
        BoundingBox probe = new BoundingBox(x0, y0, z0, x1, y1, z1);
        for (int x = (int) Math.floor(x0); x <= (int) Math.floor(x1); x++) {
            for (int y = (int) Math.floor(y0); y <= (int) Math.floor(y1); y++) {
                for (int z = (int) Math.floor(z0); z <= (int) Math.floor(z1); z++) {
                    Block bl = w.getBlockAt(x, y, z);
                    if (bl.isPassable()) continue;
                    if (bl.getBoundingBox().overlaps(probe)) return true;
                }
            }
        }
        return false;
    }

    /** Đứng trên boat / shulker / minecart. */
    public static boolean entitySupport(Player p) {
        for (Entity e : p.getNearbyEntities(1.3, 1.6, 1.3)) {
            if (e instanceof Boat || e instanceof Shulker || e instanceof Minecart) return true;
        }
        return false;
    }

    private static final String[] SPECIAL = {
            "SLIME", "HONEY", "_BED", "COBWEB", "WEB", "LADDER", "VINE", "SCAFFOLDING",
            "BUBBLE", "POWDER_SNOW", "BERRY", "TWISTING", "WEEPING", "PISTON", "TRAMPOLINE",
            "WATER", "LAVA", "KELP", "SEAGRASS", "DRIPSTONE", "SOUL_SAND"
    };

    /** Có block đặc biệt (nảy, chậm, thang, nước...) trong vùng quanh người (xuống 1.2 block). */
    public static boolean nearSpecial(World w, BoundingBox b) {
        int x0 = (int) Math.floor(b.getMinX() - 0.3), x1 = (int) Math.floor(b.getMaxX() + 0.3);
        int z0 = (int) Math.floor(b.getMinZ() - 0.3), z1 = (int) Math.floor(b.getMaxZ() + 0.3);
        int y0 = (int) Math.floor(b.getMinY() - 1.2), y1 = (int) Math.floor(b.getMaxY() + 0.1);
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) {
                    Block bl = w.getBlockAt(x, y, z);
                    Material m = bl.getType();
                    if (m == Material.AIR || m == Material.CAVE_AIR || m == Material.VOID_AIR) continue;
                    if (bl.isLiquid()) return true;
                    String n = m.name();
                    for (String k : SPECIAL) if (n.contains(k)) return true;
                }
            }
        }
        return false;
    }

    /** Có băng dưới chân (băng làm tốc độ cao hơn bình thường). */
    public static boolean onIce(World w, BoundingBox b) {
        int x0 = (int) Math.floor(b.getMinX()), x1 = (int) Math.floor(b.getMaxX());
        int z0 = (int) Math.floor(b.getMinZ()), z1 = (int) Math.floor(b.getMaxZ());
        int y = (int) Math.floor(b.getMinY() - 0.6);
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int yy = y; yy <= y + 1; yy++) {
                    if (w.getBlockAt(x, yy, z).getType().name().contains("ICE")) return true;
                }
            }
        }
        return false;
    }
}
