package vn.danchoismp.anticheat;

import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
import com.github.retrooper.packetevents.protocol.player.User;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientHeldItemChange;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

/**
 * MaceSwap: hack tự đổi sang Mace đúng lúc đánh (đang rơi để ăn smash) rồi đổi lại ngay.
 * Người thật cần >= vài chục ms giữa lúc cuộn/bấm đổi slot và lúc bấm đánh.
 * Dùng thời gian của từng packet (HELD_ITEM_CHANGE / INTERACT_ENTITY) nên không bị gộp theo tick.
 * Check này KHÔNG trùng với Grim nên luôn chạy kể cả khi có GrimAC.
 *
 * Phát hiện 3 kiểu:
 *  1) đổi sang Mace -> đánh (smash khi fallDistance cao) sau &lt; min-switch-to-attack-ms
 *  2) đổi sang Mace -> đánh -> đổi đi ngay (swap-attack-swap) trong swap-back-ms
 *  3) đổi slot quá nhiều lần mỗi giây
 * Dùng tên "MACE" theo chuỗi nên vẫn load được trên server 1.20.x (chưa có Mace).
 */
public class MaceCheck extends PacketListenerAbstract implements Listener {

    private static class State {
        // do tick chính cập nhật (main thread)
        volatile boolean[] maces = new boolean[9];
        volatile float fall;
        volatile int bukkitSlot = -1;
        // do packet thread cập nhật
        volatile int slot = -1;
        volatile long lastSwitchMs;
        volatile boolean lastSwitchWasRealChange;
        volatile long maceSwapAttackMs;     // thời điểm đánh Mace ngay sau khi đổi slot
        final Deque<Long> switches = new ArrayDeque<>();
        volatile double fastBuf;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final ConcurrentHashMap<UUID, State> states = new ConcurrentHashMap<>();

    public MaceCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        super(PacketListenerPriority.NORMAL);
        this.plugin = plugin;
        this.vm = vm;
        // chụp nhanh hotbar + fallDistance mỗi tick (an toàn: chạy ở main thread)
        Bukkit.getScheduler().runTaskTimer(plugin, this::snapshot, 1L, 1L);
    }

    private static boolean isMace(ItemStack it) {
        return it != null && it.getType().name().equals("MACE");
    }

    private void snapshot() {
        if (!plugin.isLicensed() || !plugin.configs().checks().getBoolean("mace.enabled", true)) return;
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            State s = states.computeIfAbsent(p.getUniqueId(), k -> new State());
            boolean[] m = new boolean[9];
            for (int i = 0; i < 9; i++) m[i] = isMace(p.getInventory().getItem(i));
            s.maces = m;
            s.fall = p.getFallDistance();
            s.bukkitSlot = p.getInventory().getHeldItemSlot();
            // đồng bộ slot nếu gần đây không có packet đổi slot (vd plugin khác set slot)
            if (s.slot == -1 || now - s.lastSwitchMs > 150) s.slot = s.bukkitSlot;
        }
    }

    @Override
    public void onPacketReceive(PacketReceiveEvent event) {
        PacketTypeCommon type = event.getPacketType();
        boolean held = type == PacketType.Play.Client.HELD_ITEM_CHANGE;
        boolean interact = type == PacketType.Play.Client.INTERACT_ENTITY;
        if (!held && !interact) return;

        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("mace.enabled", true)) return;

        User user = event.getUser();
        UUID id = user.getUUID();
        if (id == null) return;
        Player p = Bukkit.getPlayer(id);
        if (p == null || Util.skip(plugin, p)) return;

        State s = states.computeIfAbsent(id, k -> new State());
        long now = System.currentTimeMillis();

        if (held) {
            int newSlot = new WrapperPlayClientHeldItemChange(event).getSlot();
            if (newSlot < 0 || newSlot > 8) return;

            // 2) swap-attack-swap: vừa đánh Mace ngay sau khi đổi, lại đổi đi ngay
            long ma = s.maceSwapAttackMs;
            if (ma != 0 && now - ma <= c.getLong("mace.swap-back-ms", 70)) {
                vm.flag(p, "MaceSwap", "đổi Mace → đánh → đổi lại sau " + (now - ma) + "ms", 2.0);
                s.maceSwapAttackMs = 0;
            }

            // 3) đổi slot quá nhanh/quá nhiều
            synchronized (s.switches) {
                s.switches.addLast(now);
                while (!s.switches.isEmpty() && now - s.switches.peekFirst() > 1000) s.switches.pollFirst();
                int max = c.getInt("mace.max-switches-per-second", 14);
                if (s.switches.size() > max) {
                    vm.flag(p, "MaceSwap", "đổi slot " + s.switches.size() + " lần/giây", 1.0);
                    s.switches.clear();
                }
            }

            s.lastSwitchWasRealChange = newSlot != s.slot;
            s.slot = newSlot;
            s.lastSwitchMs = now;
            return;
        }

        // ---- INTERACT_ENTITY ----
        WrapperPlayClientInteractEntity w = new WrapperPlayClientInteractEntity(event);
        if (w.getAction() != WrapperPlayClientInteractEntity.InteractAction.ATTACK) return;

        int slot = s.slot;
        boolean holdingMace = slot >= 0 && slot <= 8 && s.maces[slot];
        if (!holdingMace) {
            s.maceSwapAttackMs = 0;
            return;
        }

        long sinceSwitch = now - s.lastSwitchMs;
        // so sánh 2 packet trên cùng 1 kết nối nên ping không làm lệch khoảng cách giữa chúng
        double minMs = c.getDouble("mace.min-switch-to-attack-ms", 60);
        boolean freshSwitch = s.lastSwitchMs != 0 && s.lastSwitchWasRealChange && sinceSwitch < c.getLong("mace.swap-window-ms", 150);
        s.maceSwapAttackMs = freshSwitch ? now : 0;

        // 1) đổi sang Mace rồi đánh smash gần như tức thì
        boolean smash = s.fall > c.getDouble("mace.min-fall-distance", 1.5);
        if (freshSwitch && smash && sinceSwitch < minMs) {
            s.fastBuf++;
            if (s.fastBuf >= c.getDouble("mace.buffer", 2)) {
                vm.flag(p, "MaceSwap", String.format("đổi Mace → smash sau %dms (rơi %.1f)", sinceSwitch, s.fall), 2.0);
                if (c.getBoolean("combat.cancel-hits", true)) event.setCancelled(true);
            }
        } else if (sinceSwitch > minMs * 2) {
            s.fastBuf = Math.max(0, s.fastBuf - 0.5);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
