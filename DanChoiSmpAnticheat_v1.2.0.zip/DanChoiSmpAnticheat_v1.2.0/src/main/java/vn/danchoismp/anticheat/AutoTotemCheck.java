package vn.danchoismp.anticheat;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;

/**
 * AutoTotem: phát hiện đưa totem vào offhand quá nhanh sau khi vừa dùng totem / nhận damage nặng.
 */
public class AutoTotemCheck implements Listener {

    private static class State {
        long lastTotemPopMs;
        long lastHeavyDamageMs;
        long lastOffhandEmptyMs;
        final Deque<Long> fastEquips = new ArrayDeque<>();
        double buffer;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public AutoTotemCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> new State());
    }

    private boolean isTotem(ItemStack it) {
        return it != null && it.getType() == Material.TOTEM_OF_UNDYING;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onResurrect(EntityResurrectEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        State s = state(p);
        s.lastTotemPopMs = System.currentTimeMillis();
        // offhand sẽ trống ngay sau pop
        s.lastOffhandEmptyMs = s.lastTotemPopMs;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (e.getFinalDamage() < p.getHealth() * 0.4) return; // chỉ damage nặng
        state(p).lastHeavyDamageMs = System.currentTimeMillis();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        if (Util.skip(plugin, p)) return;
        ItemStack main = e.getMainHandItem();
        ItemStack off = e.getOffHandItem();
        // sau swap: offhand nhận item từ main
        if (isTotem(main)) {
            checkEquip(p, "swap-hand");
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (Util.skip(plugin, p)) return;
        // đặt totem vào offhand slot (40)
        if (e.getSlot() == 40 && isTotem(e.getCursor())) {
            checkEquip(p, "inv-click");
            return;
        }
        // shift-click totem khi đang mở inventory
        if (e.isShiftClick() && isTotem(e.getCurrentItem())) {
            // có thể vào offhand nếu trống
            ItemStack off = p.getInventory().getItemInOffHand();
            if (off == null || off.getType() == Material.AIR) {
                checkEquip(p, "shift-click");
            }
        }
    }

    private void checkEquip(Player p, String method) {
        FileConfiguration c = plugin.configs().checks();
        if (!c.getBoolean("autototem.enabled", true)) return;

        State s = state(p);
        long now = System.currentTimeMillis();
        long minMs = c.getLong("autototem.min-equip-ms", 80);
        long window = c.getLong("autototem.window-ms", 3000);
        int maxFast = c.getInt("autototem.max-fast-equips", 3);

        long sincePop = now - s.lastTotemPopMs;
        long sinceDmg = now - s.lastHeavyDamageMs;
        long sinceEmpty = now - s.lastOffhandEmptyMs;

        boolean suspicious = (s.lastTotemPopMs > 0 && sincePop < minMs)
                || (s.lastHeavyDamageMs > 0 && sinceDmg < minMs + 50)
                || (s.lastOffhandEmptyMs > 0 && sinceEmpty < minMs);

        if (!suspicious) return;

        s.fastEquips.addLast(now);
        while (!s.fastEquips.isEmpty() && now - s.fastEquips.peekFirst() > window) {
            s.fastEquips.pollFirst();
        }

        if (s.fastEquips.size() >= maxFast) {
            s.buffer += 1.5;
            if (s.buffer >= c.getDouble("autototem.buffer", 2)) {
                vm.flag(p, "AutoTotem",
                        String.format("%s in %dms after pop/dmg (%d times)", method, Math.min(sincePop, sinceDmg), s.fastEquips.size()),
                        1.5);
                s.buffer = 0;
                s.fastEquips.clear();
            }
        } else if (sincePop < minMs && s.lastTotemPopMs > 0) {
            // một lần cực nhanh sau pop cũng đáng nghi
            s.buffer += 0.8;
            if (s.buffer >= c.getDouble("autototem.buffer", 2)) {
                vm.flag(p, "AutoTotem",
                        String.format("%s %dms after totem pop", method, sincePop), 1.0);
                s.buffer = Math.max(0, s.buffer - 1.0);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
